# 2048 ALPHA

## Conventions / Formatting Explanations

Within the UML diagrams, black text indicates the method / variable has been included whereas grey text indicates it is a future method / variable.

## Usage

Double click the batch file [runMe.bat](runMe.bat).

## Gameplay

To move, enter one of the following characters: l, r, u, d. These correspond to sliding to the left, right, up, and down, respectively. Invalid moves will be ignored (no feedback since this is only ALPHA program).
To quit, enter q.
